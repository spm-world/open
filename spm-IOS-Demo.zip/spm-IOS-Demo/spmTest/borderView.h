//
//  borderView.h
//  spmTest
//
//  Created by Admin on 2019/9/12.
//  Copyright © 2019 wzz. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface borderView : UIView

@end

NS_ASSUME_NONNULL_END
