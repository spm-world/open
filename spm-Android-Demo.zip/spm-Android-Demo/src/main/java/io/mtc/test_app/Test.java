package io.mtc.test_app;

public class Test {
    public static final String data = "amount=1&appId=d17e0cab3fe689e8275e93209bcb083b&nonceStr=1&orderCurrencyType=USD&orderId=1$2a$10$r2.NI/ngyaelWW8eSQPA7.Fm5iB9kNXvfc4HmqUtYOHHy.rgVp8CO";
    public static final String data2 = "a638ed42b753ed1b01a771a7611b7fab";

    public static void main(String agrs[]) {
//        System.out.println("singResult---->" + SIgnUtils.md5(data));
//        System.out.println("---->" + data2.equalsIgnoreCase(SIgnUtils.md5(data)));
        String ciphertext = SIgnUtils.encrypt(data);
        System.out.println("加密成密文：" + ciphertext);
    }
}
