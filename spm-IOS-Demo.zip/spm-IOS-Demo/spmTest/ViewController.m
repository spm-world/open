//
//  ViewController.m
//  spmTest
//
//  Created by Admin on 2019/9/12.
//  Copyright © 2019 wzz. All rights reserved.
//


#define privateKey @"$2a$10$F6uLm5RzTIT0/YhaBU9BYOiQ1Cu7ryuYWkRji6e5pu7ugdhnYPY8C"
#import "ViewController.h"
#import <CocoaSecurity.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *amountTF;
@property (weak, nonatomic) IBOutlet UITextField *orderTF;
@property (weak, nonatomic) IBOutlet UITextField *paytypeTF;
@property (weak, nonatomic) IBOutlet UILabel *appidLabel;
@property (weak, nonatomic) IBOutlet UITextField *strTF;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)payClick:(id)sender {
    
    if (self.amountTF.text.length == 0) {
        return;
    }
    if (self.orderTF.text.length == 0) {
        return;
    }
    if (self.paytypeTF.text.length == 0) {
        return;
    }
    if (self.strTF.text.length == 0) {
        return;
    }
    NSString *sign = [self signClient:@{@"nonceStr":self.strTF.text,@"orderId":self.orderTF.text,@"amount":self.amountTF.text,@"appId":self.appidLabel.text,@"orderCurrencyType":self.paytypeTF.text}];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"SPMPAY://appid=%@&amount=%@&orderID=%@&payType=%@&randomStr=%@&sign=%@&appUrl=spmThirdPay",self.appidLabel.text,self.amountTF.text,self.orderTF.text,self.paytypeTF.text,self.strTF.text,sign]];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url];
    }
    
}


//签名
- (NSString *)signClient:(NSDictionary *)info{
    //compare: 方法默认升序
    NSArray *ascendingKeys =  [[info allKeys]  sortedArrayUsingSelector:@selector(compare:)];
    NSString *valueStirng = @"";
    for (NSString *key in ascendingKeys) {
        valueStirng = [valueStirng stringByAppendingString:[NSString stringWithFormat:@"%@=%@&",key,[info valueForKey:key]]];
    }
    valueStirng = [[valueStirng substringToIndex:valueStirng.length-1] stringByAppendingString:privateKey];
    //MARK:进行md5校验,并且加入字段
    CocoaSecurityResult *result = [CocoaSecurity md5:valueStirng];
    return result.hexLower;
}
@end
