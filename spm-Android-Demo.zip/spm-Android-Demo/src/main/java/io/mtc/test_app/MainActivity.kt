package io.mtc.test_app

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.HashMap

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        to_super_money.setOnClickListener {
            toPay()
        }
    }

    private fun toPay() {
        val amount = et_amount.text.toString()
        val orderId = orderNumber.text.toString()
        val appId = et_appId.text.toString()
        val nonceStr = et_nonceStr.text.toString()
        val orderCurrencyType = orderCurrencyType.text.toString()
        val private = et_sign.text.toString()
        if (TextUtils.isEmpty(amount)) {
            showToast("请填写金额")
            return
        }
        if (TextUtils.isEmpty(orderId)) {
            showToast("请填写订单Id")
            return
        }
        if (TextUtils.isEmpty(appId)) {
            showToast("请填AppId")
            return
        }
        if (TextUtils.isEmpty(nonceStr)) {
            showToast("请填随机字符串")
            return
        }
        if (TextUtils.isEmpty(private)) {
            showToast("请填写秘钥")
            return
        }
        val sortedMap = sortedMapOf(
            "nonceStr" to nonceStr,
            "orderId" to orderId,
            "amount" to amount,
            "appId" to appId,
            "orderCurrencyType" to orderCurrencyType
        )
        val signContent = SIgnUtils.createSign(sortedMap, private)
        val intent = Intent()
        val data = Bundle()
        data.putString("amount", amount)
        data.putString("orderId", orderId)
        data.putString("appId", appId)
        data.putString("nonceStr", nonceStr)
        data.putString("sign", signContent)
        data.putString("orderCurrencyType", orderCurrencyType)
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.putExtras(data)
        val comp = ComponentName("io.mtc.app.supermoney", "io.mtc.app.supermoney.ui.activity.pay.ThirdPayActivity")
        intent.setComponent(comp)
        startActivity(intent)
    }

    private fun showToast(data: String) {
        Toast.makeText(this, data, Toast.LENGTH_SHORT).show()
    }
}
