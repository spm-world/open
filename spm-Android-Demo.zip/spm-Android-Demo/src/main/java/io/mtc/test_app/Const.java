package io.mtc.test_app;

public class Const {
    //    public static final String SIGN_STR = "$2a$10$F6uLm5RzTIT0/YhaBU9BYOiQ1Cu7ryuYWkRji6e5pu7ugdhnYPY8C";
    public static final String SIGN_STR = "$2a$10$MJyL6hp5n0wuuokjljTyvOoxwrCBnj.kri6NiN3/cy4HGcoSlShpi";
}
