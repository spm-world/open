//
//  borderView.m
//  spmTest
//
//  Created by Admin on 2019/9/12.
//  Copyright © 2019 wzz. All rights reserved.
//

#import "borderView.h"

@implementation borderView


- (void)drawRect:(CGRect)rect {
    self.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.layer.borderWidth = 1;
    self.layer.cornerRadius = 5;
}


@end
